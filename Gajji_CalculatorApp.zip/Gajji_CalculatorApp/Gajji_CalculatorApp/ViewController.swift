//
//  ViewController.swift
//  Gajji_CalculatorApp
//
//  Created by Sai Vamshi Krishna Gajji on 2/8/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultOL: UILabel!
    
    var value1:String = ""
    var value2:String = ""
    var calculation:Character = " ";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func AcBtn(_ sender: Any) {
        resultOL.text=""
        value1 = " "
        value2 = " "
        calculation = " "
    }
    
    @IBAction func CBtn(_ sender: Any) {
        if(value2 != " "){
        value2=String(value2[value2.startIndex..<value2.index(value2.endIndex,offsetBy: -1)])
        resultOL.text=value2
            }
                 
        else if(value1 != " "){
        value1=String(value1[value1.startIndex..<value1.index(value1.endIndex,offsetBy: -1)])
        resultOL.text=value1
            }
    }
    
    @IBAction func pluorminBtn(_ sender: Any) {
        
        if(value2 != " "){
                if(value2.contains(".")){
                    value2 = "\(-Double(value2)!)"
                    resultOL.text=value2
                            }
                            else{
                                value2 = "\(-Int(value2)!)"
                                resultOL.text=value2
                            }
                            
                        }
                        else if(value1 != " ") {
                            if(value1.contains(".")){
                                value1 = "\(-Double(value1)!)"
                                resultOL.text=value1
                            }
                            else{
                                value1 = "\(-Int(value1)!)"
                                resultOL.text=value1
                            }
                        }
    }
    
    @IBAction func divBtn(_ sender: Any) {
        calculation="/"
    }
    
    @IBAction func sevenBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="7"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"7"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "7"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"7"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func eightBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="8"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"8"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "8"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"8"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func nineBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="9"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"9"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "9"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"9"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func mulBtn(_ sender: Any) {
        calculation="*"
    }
    
    @IBAction func fourBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="4"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"4"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "4"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"4"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func fiveBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="5"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"5"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "5"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"5"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func sixBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="6"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"6"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "6"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"6"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func subBtn(_ sender: Any) {
        calculation="-"
    }
    
    
    @IBAction func oneBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="1"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"1"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "1"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"1"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func twoBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="2"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"2"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "2"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"2"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func threeBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="3"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"3"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "3"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"3"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func plusBtn(_ sender: Any) {
        calculation="+"
    }
    
    @IBAction func zeroBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="0"
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"0"
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "0"
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"0"
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func decBtn(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                           value1="0."
                           resultOL.text="\(value1)"
                       }else if(value1 != " " && calculation == " " ){
                           value1=value1+"."
                           resultOL.text="\(value1)"
                       }
                       else if(value2 == " " && calculation != " "){
                           value2 = "0."
                           resultOL.text="\(value2)"
                       }
                       else if(value2 != " "){
                           value2=value2+"."
                           resultOL.text="\(value2)"
                       }
    }
    
    @IBAction func percentBtn(_ sender: Any) {
        calculation="%"
    }
    
    @IBAction func equalBtn(_ sender: Any) {
        switch calculation{
                       case "+" :
                           if(value1.contains(".")){
                               let val = "\(Double(value1)! + Double(value2)!)"
                               let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                               let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                               if(dec != "0"){
                                   resultOL.text = val
                               }
                               else{
                                   resultOL.text = "\(Int(Double(value1)! + Double(value2)!))"
                               }
                               
                           }
                           else {
                               resultOL.text = "\(Int(value1)! + Int(value2)!)"
                           }
                           
                           
                       case "-" :
                        
                           if(value1.contains(".")){
                               resultOL.text = "\(Double(value1)! - Double(value2)!)"
                           }
                           else {
                               resultOL.text = "\(Int(value1)! - Int(value2)!)"
                           }
                       
                       case "*" :
                           if(value1.contains(".")){
                               resultOL.text = "\(Double(value1)! * Double(value2)!)"
                           }
                           else {
                               resultOL.text = "\(Int(value1)! * Int(value2)!)"
                           }
                           
                       case "/" :
                           if(value1.contains(".")){
                               resultOL.text = "\(Double(value1)! / Double(value2)!)"
                           }
                           else {
                               if(value2 == "0"){
                                   resultOL.text = "Not a number"
                               }
                               else{
                                   let calc = "\(Double(value1)! / Double(value2)!)"
                                   let calcindex=calc.firstIndex(of: ".")!.utf16Offset(in: calc)
                                   let last = calc[calc.index(calc.startIndex,offsetBy: calcindex+1)]
                                   if(last != "0"){
                                       resultOL.text = "\(round(Double(calc)!*100000)/100000)"
                                   }
                                   else{
                                       resultOL.text = "\(Int(value1)! / Int(value2)!)"
                                   }
                               }
                               
                           }
                           
                       case "%" :
                           
                           if(value1.contains(".")){
                               var val = Double(value1)!.truncatingRemainder(dividingBy: Double(value2)!)
                               resultOL.text = "\(round(val*10)/10)"
                           }
                           else {
                               resultOL.text = "\(Int(value1)! % Int(value2)!)"
                           }
                       
                           
                       default:
                           print("enter proper sign")
                    
                       
                      }

    }
    
    
    
    
    
}

