//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Gajji,Sai Vamshi Krishna on 2/22/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var crsNumOL: UILabel!
    
    @IBOutlet weak var previousOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    @IBOutlet weak var crsTitleOL: UILabel!
    
    @IBOutlet weak var semOL: UILabel!
    
    //populate an array
    let courses = [["img01","44555","Network Security","Fall"],["img02","44666","iOS","Spring"],["img03","44556","Data Streaming","Summer"]]
    var imgNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //previous button should be disabled
        previousOL.isEnabled = false;
        
        //dispaly the first course details(index 0)
        updateContents(imgNum)
        
    }

    @IBAction func prevBtnClicked(_ sender: Any) {
        //next button should be enabled
        nextOL.isEnabled = true;
        
       // decrement the image number
        imgNum = imgNum-1;
        
        //update the contents
        updateContents(imgNum)
        
        //once you reach the beginning of the array, the previous button should be disbaled
        if(imgNum == 0){
            previousOL.isEnabled = false;
        }
    }
    
    @IBAction func nextBtnClicked(_ sender: Any) {
        // previous button is enabled
        previousOL.isEnabled = true;
        
        //increment the image number
        imgNum = imgNum+1;
        
        //updating the course details
        updateContents(imgNum)
        
        //once the user reach the end of the array the next button should be enabled
        if(imgNum == courses.count-1){
            nextOL.isEnabled = false;
        }
        
    }//end of nextBtn
        //this is a helper function to update contents
        func updateContents(_ imageNumber:Int){
            imageOL.image = UIImage(named: courses[imageNumber][0])
            crsNumOL.text = courses[imageNumber][1]
            crsTitleOL.text = courses[imageNumber][2]
            semOL.text = courses[imageNumber][3]
        
    }
}

