//
//  ViewController.swift
//  Kunkala_PracticeExam01
//
//  Created by Kunkala,Nagarjuna Reddy on 2/13/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var heightFeetOL: UITextField!

    @IBOutlet weak var heightInchOL: UITextField!
    
    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var resultOL: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btnCalculateBMI(_ sender: Any) {
        let height = Double(heightFeetOL.text!)! * 12 + Double(heightInchOL.text!)!
        let weight = Double(weightOL.text!)!
        
        let bmi = 703*weight*(1/(height*height))
        var report = ""
        
        if bmi <= 18.5 {
            report = "UnderWeight"
            imageOL.image = UIImage(named: "underWeight.jpeg")
        } else if bmi <= 24.9 {
            report = "Normal👍"
            imageOL.image = UIImage(named: "normal.jpeg")
        } else if bmi <= 29.9 {
            report = "Overweight"
            imageOL.image = UIImage(named: "overWeight.jpeg")
        } else {
            report = "Obesity"
            imageOL.image = UIImage(named: "obese.jpeg")
        }
        
        
        resultOL.text = "Your Body Mass Index is \(String(format: "%.1f", bmi)). \n This is considered as \(report)."
        
        
    }
}

