//
//  ViewController.swift
//  Gajji_Assignment02
//
//  Created by Sai Vamshi Krishna Gajji on 1/31/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var dateOutlet: UIDatePicker!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: Any) {
        
        let dateFormatter = DateFormatter();
        dateFormatter.dateFormat = "MM-dd-yyyy hh:mm:ss"
        let date = dateFormatter.string(from: Date())
        dateLabel.text = date
        var billamnt = Double(billAmountOutlet.text!)!
        var tipcnt = Double(tipPercentageOutlet.text!)!
        var tipamnt = billamnt * 0.01 * tipcnt
        var totalamnt = Double(tipamnt + billamnt)
        
        nameLabel.text = "Name : \(nameOutlet.text!)"
        billAmountLabel.text = "Bill Amount : $ \(billAmountOutlet.text!)"
        tipAmountLabel.text = "Tip Amount : $ \(tipamnt)"
        totalAmountLabel.text = "Total Amount : $\(totalamnt) "
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        dateLabel.text = ""
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""
    }
    
}

