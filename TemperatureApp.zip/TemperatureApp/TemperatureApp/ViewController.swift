//
//  ViewController.swift
//  TemperatureApp
//
//  Created by Gajji,Sai Vamshi Krishna on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var outputOL: UILabel!
    
    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL1: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func CheckBtnClicked(_ sender: Any) {
        
        //Enter the temperature
        var input = Int(inputOL.text!)
        
        
        //Check temperature using if
        if(input! >= 60){
            print("It's hot outside")
            
            outputOL1.text = "It's hot outside"
        }
        else{
            print("It's cold")
            
            outputOL1.text = "It's cold"
        }
        
    }
}

