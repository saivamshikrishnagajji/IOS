import UIKit

var greeting = "Hello, playground"

var capitals = ["Telanagana" : "Hydderabad", "Andhra Pradesh" : "Amarvathi" , "Tamil Nadu" : "Chennai", "Karnataka": "Bangalore"]
print(capitals)

print(capitals.count)

var numbers = [1:"One",2:"Two",3:"Three"]
print(numbers)

numbers[4] = "Four"
print(numbers)

var courses = [44542:"Java",44560:"Database",44613:"Data Visualisation"]

print("Before changing\(courses)")
courses[44542] = "Java Script"
print("After changing \(courses)")

print(courses[44542])

courses.removeValue(forKey: 44560)
print(courses)

for(key,values) in courses{
    print(key)
}

for(key,values) in courses{
    print(values)
}

for(key,values) in courses{
    print("\(key) : \(values)")
}
