//
//  ViewController.swift
//  Gajji_PracticeExam01
//
//  Created by Gajji,Sai Vamshi Krishna on 2/13/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOL: UILabel!
    
    @IBOutlet weak var heightFeetOL: UITextField!
    
    @IBOutlet weak var heightinOL: UITextField!
    
    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var opOL: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func calculateBTN(_ sender: Any) {
        
        let feet = Double(heightFeetOL.text!)!
        let inch = Double(heightinOL.text!)!
        let weight = Double(weightOL.text!)!
        
        let height = 12 * feet + inch
        let BMI = (703 * (weight)) / (height * height)
        
        if(BMI <= 18.5){
            opOL.text = "Your Body Mass Index is \(String(format: "%.1f", BMI)). \n This is considered as Under Weight"
            imageOL.image = UIImage(named:"underWeight.jpeg")
        }else if(BMI > 18.5 && BMI <= 24.9){
            opOL.text = "Your Body Mass Index is \(String(format: "%.1f", BMI)). \n This is considered as Normal"
            imageOL.image = UIImage(named:"normal.jpeg")
        }else if(BMI > 25 && BMI < 29.9){
            opOL.text = "Your Body Mass Index is \(String(format: "%.1f", BMI)). \n This is considered as Overweight"
            imageOL.image = UIImage(named:"overWeight.jpeg")
        } else {
            opOL.text = "Your Body Mass Index is \(String(format: "%.1f", BMI)). \n This is considered as Obesity"
            imageOL.image = UIImage(named:"obese.jpeg")
        }
        
        
        
    }
    
}

