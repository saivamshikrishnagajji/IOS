import UIKit

print("Hii",10,12.25)

print("Hello World!👋")

var age = "23"
print("My age is \(age)")

print("Welcome to Swift Programming")
print("Fall 2021")

print("Welcome to Swift Programming" , terminator: "~")
print("Fall 2021")

print("The list of numbers are ")
print(1,2,3,4,5,6)

print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
