//
//  ViewController.swift
//  VowelFinder
//
//  Created by Gajji,Sai Vamshi Krishna on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var ouputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CheckBtnClicked(_ sender: Any) {
        
        //Read the enetred text and assign it to a variable.
        var input  = inputOL.text!
        
        //Check for vowels using If.
        if(input.contains("a") || input.contains("e") || input.contains("i") || input.contains("o") || input.contains("u")) {
            //Print the message.
            print("\(input) contains vowels ")
            //Assign the output to output label
            ouputOL.text = "\(input) contains vowels "
        }
        else{
            //Print the message
            print("\(input) doesn't contain any vowels ")
            //Assign the output to output label
            ouputOL.text = "\(input) doesn't contain any vowels "
        }
        
        
    }
    
}

